// This is your test secret API key.
const stripe = require('stripe')('pk_test_51PIX6lCcJtP9jRNe1y6eeOoQaMdFHTvnB06ywoPthDP7muAdx3XJ5WbBcuVsGoQ4AYCNXtgdMM68dNGl73nlphq600AN7LPdeR');
const express = require('express');
const app = express();

app.use(express.json()); // ✅ เพิ่ม middleware สำหรับ JSON
app.use(express.static('public'));

const YOUR_DOMAIN = 'http://localhost:3000';

// ✅ เพิ่ม Route สำหรับหน้าแรก
app.get("/", (req, res) => {
  res.send("Welcome to Stripe Checkout Server!");
});

app.post('/create-checkout-session', async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price: 'price_1Qi5YWCcJtP9jRNeHARHBoCp', // 👈 ใส่ Price ID จริงที่ได้จาก Stripe
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${YOUR_DOMAIN}/success.html`,
      cancel_url: `${YOUR_DOMAIN}/cancel.html`,
    });

    res.redirect(303, session.url); // ✅ Redirect ไปยัง Stripe Checkout
  } catch (error) {
    console.error("Error creating checkout session:", error);
    res.status(500).send("Internal Server Error");
  }
});


app.listen(3000, () => console.log('Running on port 3000'));

//price_1Qi5YWCcJtP9jRNeHARHBoCp